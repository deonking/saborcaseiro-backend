// js/geolocalizacao.js
// Busca localização do usuário via IPinfo e salva nos cookies para uso no site

async function buscarGeolocalizacao() {
    try {
        const response = await fetch('https://ipinfo.io/json?token=4df0baa0bf8b64'); // Substitua 'demo' por um token próprio se desejar
        if (!response.ok) throw new Error('Erro ao buscar localização');
        const data = await response.json();
        // data.city, data.region, data.country
        if (data.city) setCookie('localCidade', data.city, 2);
        if (data.region) setCookie('localEstado', data.region, 2);
        if (data.country) setCookie('localPais', data.country, 2);
        // Atualiza elementos na página se existirem
        if (document.getElementById('localCidade')) document.getElementById('localCidade').textContent = data.city || 'Sua região';
    } catch (e) {
        // fallback
        if (document.getElementById('localCidade')) document.getElementById('localCidade').textContent = 'Sua região';
    }
}

// Chama automaticamente ao carregar
window.addEventListener('DOMContentLoaded', buscarGeolocalizacao);
